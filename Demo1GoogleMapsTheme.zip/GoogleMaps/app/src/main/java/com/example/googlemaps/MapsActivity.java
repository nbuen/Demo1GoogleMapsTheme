package com.example.googlemaps;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapsActivity extends AppCompatActivity implements OnMyLocationButtonClickListener, OnMyLocationClickListener, OnMapReadyCallback {

    private GoogleMap mMap;

    private ArrayList<MarkerOptions> arrayList;

    private LatLng  sydney = new LatLng(-34, 151),
            tokyo = new LatLng(35.6895, 139.6917),
            manila = new LatLng(14.5995, 120.9842),
            winnipeg = new LatLng(49.8951, -97.1384);

    private int checkItem = 0;

    private static final CharSequence[] MAP_TYPE_ITEMS =
            {"Road Map", "Hybrid", "Satellite", "Terrain"};

    private static final CharSequence[] MARKER_ITEMS =
            {"Sydney", "Tokyo", "Manila", "Winnipeg"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        arrayList = new ArrayList<MarkerOptions>();

        arrayList.add(0, new MarkerOptions().position(sydney).title("Marker in Sydney"));

        arrayList.add(1, new MarkerOptions().position(tokyo).title("Marker in Tokyo").icon(BitmapDescriptorFactory.fromResource(R.drawable.jp_marker)).snippet("Soon!!"));
        arrayList.add(2, new MarkerOptions().position(manila).title("Marker in Manila").icon(BitmapDescriptorFactory.fromResource(R.drawable.ph_marker)).snippet("Home Country"));
        arrayList.add(3, new MarkerOptions().position(winnipeg).title("Marker in PegCity!").icon(BitmapDescriptorFactory.fromResource(R.drawable.ca_marker)).snippet("PEGCITY NUMBAWAN"));

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // This try catch will check if a custom style exists in the raw resource directory
        try {
            // Customise the styling of the base map using a JSON object defined
            // in a raw resource file.
            boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            this, R.raw.mapsnightstyle));

            if (!success) {
                Log.e("MapsStyle", "Style parsing failed.");
            }
        } catch (Resources.NotFoundException e) {
            Log.e("MapsStyle", "Can't find style. Error: ", e);
        }

        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMyLocationClickListener(this);

        //turning on the my location layer
        //(runtime location permission is required)
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            Log.d("Jody", "enabling my location");
            mMap.setMyLocationEnabled(true);
        } else {
            // Show rationale and request permission.
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }


        for (MarkerOptions markerOptions : arrayList) {
            mMap.addMarker(markerOptions);
        }

        mMap.moveCamera(CameraUpdateFactory.newLatLng(winnipeg));
        mMap.animateCamera( CameraUpdateFactory.zoomTo( 17.0f ) );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_items, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item_settings:
                showMapTypeSelectorDialog();
                return true;
            case R.id.item_flymarker:
                showMarkerSelectorDialog();
            default :
                return super.onOptionsItemSelected(item);
        }
    }

    private void showMapTypeSelectorDialog() {
        // Prepare the dialog by setting up a Builder.
        final String fDialogTitle = "Select Map Type";
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(fDialogTitle);

        // Find the current map type to pre-check the item representing the current state.
        int checkItem = mMap.getMapType() - 1;

//        private static final CharSequence[] MAP_TYPE_ITEMS =
//                {"Road Map", "Hybrid", "Satellite", "Terrain"};

        // Add an OnClickListener to the dialog, so that the selection will be handled.
        builder.setSingleChoiceItems(
                MAP_TYPE_ITEMS,
                checkItem,
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int item) {
                        // Locally create a finalised object.

                        // Perform an action depending on which item was selected.
                        switch (item) {
                            case 1:
                                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                                Log.d("Jody", "Selected: " + item);
                                break;
                            case 2:
                                mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                                Log.d("Jody", "Selected: " + item);
                                break;
                            case 3:
                                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                                Log.d("Jody", "Selected: " + item);
                                break;
                            default:
                                Log.d("Jody", "Selected: " + item);
                                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                        }
                        dialog.dismiss();
                    }
                }
        );

        // Build the dialog and show it.
        AlertDialog fMapTypeDialog = builder.create();
        fMapTypeDialog.setCanceledOnTouchOutside(true);
        fMapTypeDialog.show();
    }

    private void showMarkerSelectorDialog() {
        // Prepare the dialog by setting up a Builder.
        final String fDialogTitle = "Select Marked Location to Fly";
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(fDialogTitle);



        // Add an OnClickListener to the dialog, so that the selection will be handled.
        builder.setSingleChoiceItems(
                MARKER_ITEMS,
                checkItem,
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int item) {
                        // Locally create a finalised object.

                        // Perform an action depending on which item was selected.
                        switch (item) {
                            case 1:
                                checkItem = 1;
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(tokyo));
                                Log.d("Jody", "Selected: " + item);
                                break;
                            case 2:
                                checkItem = 2;
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(manila));
                                Log.d("Jody", "Selected: " + item);
                                break;
                            case 3:
                                checkItem = 3;
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(winnipeg));
                                Log.d("Jody", "Selected: " + item);
                                break;
                            default:
                                checkItem = 0;
                                Log.d("Jody", "Selected: " + item);
                                mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                        }
                        dialog.dismiss();
                    }
                }
        );

        // Build the dialog and show it.
        AlertDialog fMapTypeDialog = builder.create();
        fMapTypeDialog.setCanceledOnTouchOutside(true);
        fMapTypeDialog.show();
    }

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {
        Toast.makeText(this, "Current location:\n" + location, Toast.LENGTH_LONG).show();
    }
}
